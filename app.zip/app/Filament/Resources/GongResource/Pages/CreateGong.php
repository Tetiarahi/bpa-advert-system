<?php

namespace App\Filament\Resources\GongResource\Pages;

use App\Filament\Resources\GongResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateGong extends CreateRecord
{
    protected static string $resource = GongResource::class;
}
