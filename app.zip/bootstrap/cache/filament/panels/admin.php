<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.activity-log-resource.pages.list-activity-logs' => 'App\\Filament\\Resources\\ActivityLogResource\\Pages\\ListActivityLogs',
    'app.filament.resources.activity-log-resource.pages.view-activity-log' => 'App\\Filament\\Resources\\ActivityLogResource\\Pages\\ViewActivityLog',
    'app.filament.resources.activity-log-resource.widgets.activity-log-stats-widget' => 'App\\Filament\\Resources\\ActivityLogResource\\Widgets\\ActivityLogStatsWidget',
    'app.filament.resources.ads-category-resource.pages.create-ads-category' => 'App\\Filament\\Resources\\AdsCategoryResource\\Pages\\CreateAdsCategory',
    'app.filament.resources.ads-category-resource.pages.edit-ads-category' => 'App\\Filament\\Resources\\AdsCategoryResource\\Pages\\EditAdsCategory',
    'app.filament.resources.ads-category-resource.pages.list-ads-categories' => 'App\\Filament\\Resources\\AdsCategoryResource\\Pages\\ListAdsCategories',
    'app.filament.resources.advertisement-resource.pages.create-advertisement' => 'App\\Filament\\Resources\\AdvertisementResource\\Pages\\CreateAdvertisement',
    'app.filament.resources.advertisement-resource.pages.edit-advertisement' => 'App\\Filament\\Resources\\AdvertisementResource\\Pages\\EditAdvertisement',
    'app.filament.resources.advertisement-resource.pages.list-advertisements' => 'App\\Filament\\Resources\\AdvertisementResource\\Pages\\ListAdvertisements',
    'app.filament.resources.advertisement-resource.pages.view-advertisement' => 'App\\Filament\\Resources\\AdvertisementResource\\Pages\\ViewAdvertisement',
    'app.filament.resources.customer-resource.pages.create-customer' => 'App\\Filament\\Resources\\CustomerResource\\Pages\\CreateCustomer',
    'app.filament.resources.customer-resource.pages.edit-customer' => 'App\\Filament\\Resources\\CustomerResource\\Pages\\EditCustomer',
    'app.filament.resources.customer-resource.pages.list-customers' => 'App\\Filament\\Resources\\CustomerResource\\Pages\\ListCustomers',
    'app.filament.resources.gong-resource.pages.create-gong' => 'App\\Filament\\Resources\\GongResource\\Pages\\CreateGong',
    'app.filament.resources.gong-resource.pages.edit-gong' => 'App\\Filament\\Resources\\GongResource\\Pages\\EditGong',
    'app.filament.resources.gong-resource.pages.list-gongs' => 'App\\Filament\\Resources\\GongResource\\Pages\\ListGongs',
    'app.filament.resources.gong-resource.pages.view-gong' => 'App\\Filament\\Resources\\GongResource\\Pages\\ViewGong',
    'app.filament.resources.presenter-resource.pages.create-presenter' => 'App\\Filament\\Resources\\PresenterResource\\Pages\\CreatePresenter',
    'app.filament.resources.presenter-resource.pages.edit-presenter' => 'App\\Filament\\Resources\\PresenterResource\\Pages\\EditPresenter',
    'app.filament.resources.presenter-resource.pages.list-presenters' => 'App\\Filament\\Resources\\PresenterResource\\Pages\\ListPresenters',
    'app.filament.resources.presenter-resource.pages.view-presenter' => 'App\\Filament\\Resources\\PresenterResource\\Pages\\ViewPresenter',
    'app.filament.resources.presenter-resource.relation-managers.read-statuses-relation-manager' => 'App\\Filament\\Resources\\PresenterResource\\RelationManagers\\ReadStatusesRelationManager',
    'app.filament.resources.program-resource.pages.create-program' => 'App\\Filament\\Resources\\ProgramResource\\Pages\\CreateProgram',
    'app.filament.resources.program-resource.pages.edit-program' => 'App\\Filament\\Resources\\ProgramResource\\Pages\\EditProgram',
    'app.filament.resources.program-resource.pages.list-programs' => 'App\\Filament\\Resources\\ProgramResource\\Pages\\ListPrograms',
    'app.filament.resources.program-resource.pages.view-program' => 'App\\Filament\\Resources\\ProgramResource\\Pages\\ViewProgram',
    'app.filament.resources.role-resource.pages.list-roles' => 'App\\Filament\\Resources\\RoleResource\\Pages\\ListRoles',
    'app.filament.resources.user-resource.pages.create-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser',
    'app.filament.resources.user-resource.pages.edit-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\EditUser',
    'app.filament.resources.user-resource.pages.list-users' => 'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers',
    'app.filament.pages.auth.login' => 'App\\Filament\\Pages\\Auth\\Login',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'app.filament.widgets.advertisements-this-month-widget' => 'App\\Filament\\Widgets\\AdvertisementsThisMonthWidget',
    'app.filament.widgets.recent-activity-widget' => 'App\\Filament\\Widgets\\RecentActivityWidget',
    'app.filament.widgets.recent-advertisements-table-widget' => 'App\\Filament\\Widgets\\RecentAdvertisementsTableWidget',
    'app.filament.widgets.recent-gongs-table-widget' => 'App\\Filament\\Widgets\\RecentGongsTableWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'bezhan-salleh.filament-shield.resources.role-resource.pages.list-roles' => 'BezhanSalleh\\FilamentShield\\Resources\\RoleResource\\Pages\\ListRoles',
    'bezhan-salleh.filament-shield.resources.role-resource.pages.create-role' => 'BezhanSalleh\\FilamentShield\\Resources\\RoleResource\\Pages\\CreateRole',
    'bezhan-salleh.filament-shield.resources.role-resource.pages.view-role' => 'BezhanSalleh\\FilamentShield\\Resources\\RoleResource\\Pages\\ViewRole',
    'bezhan-salleh.filament-shield.resources.role-resource.pages.edit-role' => 'BezhanSalleh\\FilamentShield\\Resources\\RoleResource\\Pages\\EditRole',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'C:\\Users\\IT-Dev\\Desktop\\filament-projects\\Advert-Management-System\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'C:\\Users\\IT-Dev\\Desktop\\filament-projects\\Advert-Management-System\\app\\Filament\\Resources\\ActivityLogResource.php' => 'App\\Filament\\Resources\\ActivityLogResource',
    'C:\\Users\\IT-Dev\\Desktop\\filament-projects\\Advert-Management-System\\app\\Filament\\Resources\\AdsCategoryResource.php' => 'App\\Filament\\Resources\\AdsCategoryResource',
    'C:\\Users\\IT-Dev\\Desktop\\filament-projects\\Advert-Management-System\\app\\Filament\\Resources\\AdvertisementResource.php' => 'App\\Filament\\Resources\\AdvertisementResource',
    'C:\\Users\\IT-Dev\\Desktop\\filament-projects\\Advert-Management-System\\app\\Filament\\Resources\\CustomerResource.php' => 'App\\Filament\\Resources\\CustomerResource',
    'C:\\Users\\IT-Dev\\Desktop\\filament-projects\\Advert-Management-System\\app\\Filament\\Resources\\GongResource.php' => 'App\\Filament\\Resources\\GongResource',
    'C:\\Users\\IT-Dev\\Desktop\\filament-projects\\Advert-Management-System\\app\\Filament\\Resources\\PresenterResource.php' => 'App\\Filament\\Resources\\PresenterResource',
    'C:\\Users\\IT-Dev\\Desktop\\filament-projects\\Advert-Management-System\\app\\Filament\\Resources\\ProgramResource.php' => 'App\\Filament\\Resources\\ProgramResource',
    'C:\\Users\\IT-Dev\\Desktop\\filament-projects\\Advert-Management-System\\app\\Filament\\Resources\\UserResource.php' => 'App\\Filament\\Resources\\UserResource',
    0 => 'BezhanSalleh\\FilamentShield\\Resources\\RoleResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'C:\\Users\\IT-Dev\\Desktop\\filament-projects\\Advert-Management-System\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    'C:\\Users\\IT-Dev\\Desktop\\filament-projects\\Advert-Management-System\\app\\Filament\\Widgets\\AdvertisementsThisMonthWidget.php' => 'App\\Filament\\Widgets\\AdvertisementsThisMonthWidget',
    'C:\\Users\\IT-Dev\\Desktop\\filament-projects\\Advert-Management-System\\app\\Filament\\Widgets\\RecentActivityWidget.php' => 'App\\Filament\\Widgets\\RecentActivityWidget',
    'C:\\Users\\IT-Dev\\Desktop\\filament-projects\\Advert-Management-System\\app\\Filament\\Widgets\\RecentAdvertisementsTableWidget.php' => 'App\\Filament\\Widgets\\RecentAdvertisementsTableWidget',
    'C:\\Users\\IT-Dev\\Desktop\\filament-projects\\Advert-Management-System\\app\\Filament\\Widgets\\RecentGongsTableWidget.php' => 'App\\Filament\\Widgets\\RecentGongsTableWidget',
    0 => 'App\\Filament\\Widgets\\AdvertisementsThisMonthWidget',
    1 => 'App\\Filament\\Widgets\\RecentAdvertisementsTableWidget',
    2 => 'App\\Filament\\Widgets\\RecentGongsTableWidget',
    3 => 'App\\Filament\\Widgets\\RecentActivityWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => 'C:\\Users\\IT-Dev\\Desktop\\filament-projects\\Advert-Management-System\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);